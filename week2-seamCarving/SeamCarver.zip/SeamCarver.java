import java.awt.Color;

public class SeamCarver {
    private static final boolean DEBUG = false;
    private static final double BORDER_ENERGY = 195075.0;
    private static final int  ENERGY_METHOD_DOUBLE_GRADIENT = 1;
    private static final int CURRENTENERTYMETHOD = ENERGY_METHOD_DOUBLE_GRADIENT;
    private Picture pic;
    private int width;
    private int height;

    private double[][] energyMatrix;
    private double[][] energyMatrixBack;

    private int[][] seamVPathTo;
    private int[][] seamVDestTo;


    private Color[][]  pixelMatrix;

    public SeamCarver(Picture picture) {
        pic = picture;
        width = pic.width();
        height = pic.height();
        energyMatrix = new double[height][width];
        energyMatrixBack = new double[width][height];
        initEnergyMatrix();
        pixelMatrix = new Color[height][width];
        setupPictureMatrix(pic, pixelMatrix);

        if (DEBUG)
            StdOut.println("width: " + width + " height " + height);
    }

    private void setupPictureMatrix(Picture p, Color[][] pixels)
    {
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++)
                pixels[i][j] = p.get(j, i);      // ??? because the
                                                 // pixel of image is
                                                 // different form
                                                 // bi,j.
        }
    }

    private void initEnergyMatrix()
    {
        int i, j;
        
        for (i = 0; i < width; i++)
            energyMatrix[0][i] = BORDER_ENERGY;

        for (i = 0; i < width; i++)
            energyMatrix[height - 1][i] = BORDER_ENERGY;

        for (i = 0; i < height; i++)
            energyMatrix[i][0] = BORDER_ENERGY;

        for (i = 0; i < height; i++)
            energyMatrix[i][width - 1] = BORDER_ENERGY;

        for (int h = 1; h < height - 1; h++)
            for (int w = 1; w < width - 1; w++)
                energyMatrix[h][w] = deltaX(h, w) + deltaY(h, w);
    }
    
    // calc the deltaX of column x, and row y...
    private long deltaX(int y, int x)
    {
        Color x1y = pic.get(x - 1, y);
        Color x11y = pic.get(x + 1, y);

        int r = Math.abs(x11y.getRed() - x1y.getRed());
        int g = Math.abs(x11y.getGreen() - x1y.getGreen());
        int b = Math.abs(x11y.getBlue() - x1y.getBlue());
        return ((r * r) + (g * g) + (b * b));
    }

    private long deltaY(int y, int x)
    {
        Color x1 = pic.get(x, y - 1);
        Color x2 = pic.get(x, y + 1);
        int r = Math.abs(x1.getRed() - x2.getRed());
        int g = Math.abs(x1.getGreen() - x2.getGreen());
        int b = Math.abs(x1.getBlue() - x2.getBlue());
        return ((r * r) + (g * g) + (b * b));
    }

    // current picture
    public Picture picture()
    {
        Picture p = new Picture(width, height);

        for (int i = 0; i < height; i++)
            for (int j = 0; j < width; j++) {
                p.set(j, i, pixelMatrix[i][j]);
            }
        pic = p;
        return p;
    }

    // width of current picture
    public int width()                        
    {
        return width;
    }
    
    // height of current pciture
    public     int height()     
    {
        return height;
    }

    // energy of pixel at column x and row y
    public  double energy(int x, int y)
    {
        if (x < 0 || x >= width || y < 0 || y >= height)
            throw new IndexOutOfBoundsException("out of bounds");

        if (CURRENTENERTYMETHOD ==  ENERGY_METHOD_DOUBLE_GRADIENT)
            return energyMatrix[y][x];

        return 0.0f;
    }

    // sequence of
    // indices for
    // horizontal seam

    private void initSeamPathArrays(int [][]distTo,
                                    int    [][]pathTo,
                                    int    pheight,
                                    int    pwidth)
    {

        if (DEBUG)
            StdOut.printf("init seam with height:%d width:%d\n", pheight, pwidth);
        
        for (int j = 0; j < pheight; j++)
            for (int i = 0; i < pwidth; i++)
                pathTo[j][i] = 0;

        for (int j = 0; j < pheight; j++)
            for (int i = 0; i < pwidth; i++)
                distTo[j][i] = 0x7fffffff;

        for (int i = 1; i < pwidth; i++)
            distTo[0][i] = (int) energyMatrix[0][i];

    }

    private void initSeamPathSpace() {
        if (seamVPathTo == null || seamVDestTo == null) {
            int sz = Math.max(height, width);
            seamVDestTo = new int[sz][sz];
            seamVPathTo = new int[sz][sz];
        }
    }

    private int[] doFindSeam(int [][]pathTo, int [][]distTo,
                             int pheight, int pwidth)
    {

        for (int h = 0; h < pheight - 1; h++)
            for (int w = 1; w < pwidth - 1; w++)
                relax(h, w, distTo, pathTo, pheight, pwidth);

        //        dumpDistMap(pwidth, pheight, distTo);
        //        dumpDistMap(pwidth, pheight, pathTo);

        // find last - 1 line, min weight index.
        int minidx = findMinValue(distTo, pheight - 2, pwidth);

        Stack<Integer> stack = new Stack<Integer>();

        stack.push(minidx);

        int idx = minidx;
        for (int i = pheight - 1; i > 0; i--) {
            stack.push(pathTo[i][idx]);
            idx = pathTo[i][idx];
        }

        int []a = new int[pheight];
        for (int i = 0; i < pheight; i++)
            a[i] = stack.pop();
        
        return a;
    }

    private int findMinValue(int[][]distTo, int row, int pwidth) {
        double temp = 0x7fffffff;
        int minidx = -1;
        for (int i = 0; i < pwidth; i++) {
            int val = distTo[row][i];
            if (val < temp) {
                temp = val;
                minidx = i;
            }
        }
        return minidx;
    }

    // sequence of indices for vertical seam
    public   int[] findVerticalSeam()
    {
        if (DEBUG) 
            StdOut.println("findVerticalSeam");
        initSeamPathSpace();

        initSeamPathArrays(seamVDestTo, seamVPathTo, height, width);

        return doFindSeam(seamVPathTo, seamVDestTo, height, width);
    }
    
// rotate the array, then rotate back.
    public   int[] findHorizontalSeam()
    {
        if (DEBUG)
            StdOut.println("findHorizontalSeam");
        int[] result;
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                energyMatrixBack[i][j] = energyMatrix[j][i];
            }
        }

        double [][]tp = energyMatrix;
        energyMatrix =  energyMatrixBack;

        initSeamPathSpace();
        initSeamPathArrays(seamVDestTo, seamVPathTo, width, height);


        // ....
        result = doFindSeam(seamVPathTo, seamVDestTo, width, height);

        energyMatrix = tp;
        return result;
    }


    // private void dumpDistMap(int w, int h, double[][] distTo)
    // {
    //     for (int j = 0; j < h; j++) {
    //         for (int  i = 0; i < w; i++)
    //             StdOut.printf(" \t%.2f ", distTo[j][i]);
    //     StdOut.printf("\n");
    //     }
    // }

    // private void dumpDistMap(int w, int h, int[][] distTo)
    // {
    //     for (int j = 0; j < h; j++) {
    //         for (int  i = 0; i < w; i++)
    //             StdOut.printf(" \t%d ", distTo[j][i]);
    //     StdOut.printf("\n");
    //     }
    // }


    // relax the next layer 's three nodes.
    private void relax(int layer, int pos, int [][] distTo,
                       int [][] edgeTo, int pheight, int pwidth) 
    {
        if (layer + 1 >= pheight)
            throw new IndexOutOfBoundsException("relax too much further, fix it");
        if (pos - 1 >= 0)
            relax0(layer, pos, layer + 1, pos - 1, distTo, edgeTo);
        if (pos + 1 < pwidth)
            relax0(layer, pos, layer + 1, pos + 1, distTo, edgeTo);
        relax0(layer, pos, layer + 1, pos, distTo, edgeTo);
    }

    private void relax0(int layer, int pos, int targetl, int targetp,
                        int [][] distTo, int [][]edgeTo)
    {
        //        StdOut.printf("relax0: old: [%d %d] new [%d %d]\n",
        //                      layer, pos, targetl, targetp);
        // the edge to only store ont col number, since the layer
        // number is know, it was the n - 1 layer.
        double newe = energyMatrix[targetl][targetp];
        if (distTo[targetl][targetp] > distTo[layer][pos] + (int) newe) {
            edgeTo[targetl][targetp] = pos;
            distTo[targetl][targetp] = distTo[layer][pos] + (int) newe;
        }
    }
    
    // remove horizontal seam from picture
    public    void removeHorizontalSeam(int[] a)
    {
        if (a.length != width)
            throw new IllegalArgumentException("");
        
    }

    private void arrayRemoveItem(double []a, int index)
    {
        for (int i = index; i < a.length - 1; i++) {
            a[i] = a[i+1];
        }
    }

    private void arrayRemoveItem(Color []a, int index)
    {
        for (int i = index; i < a.length - 1; i++) {
            a[i] = a[i+1];
        }
    }

    // remove vertical seam from picture
    public    void removeVerticalSeam(int[] array)
    {
        if (array.length != height)
            throw new IllegalArgumentException("");
        // first, remove it from energyMatrix,
        int h = 0;
        for (int i : array) {
            arrayRemoveItem(energyMatrix[h], i);
            h++;
        }

        // then removeo the pixel from the vector of pixel...
        h = 0;
        for (int i : array) {
            arrayRemoveItem(pixelMatrix[h], i);
            h++;
        }
        // then reduce the height;
        width--;
    }
}


/*
Exceptions. Your code should throw an exception when called with
invalid arguments.

By convention, the indices x and y are integers between 0 and W and
between 0 and H 1 respectively. Throw a
java.lang.IndexOutOfBoundsException if either x or y is outside its
prescribed range.  Throw a java.lang.IllegalArgumentException if
removeVerticalSeam() or removeHorizontalSeam() is called with an array
of the wrong length or if the array is not a valid seam (i.e., two
consecutive entries differ by more than 1).  Throw a
java.lang.IllegalArgumentException if either removeVerticalSeam() or,
removeHorizontalSeam() is called when either the width or height is
less than or equal to 1.

*/
  
